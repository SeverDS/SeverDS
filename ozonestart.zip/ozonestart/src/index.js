//Чекбокс

 // let checkbox = document.queruSelector('#discount-checkbox');


/*

Новый Вид

checkbox.addEventListener('change', function(){

    console.log('ddd');

});


  Устаревший вид

   checkbox.onchange = function() {
   console.log('ddd');
   };

console.log('checkbox');

*/

//_________Чекбокс

const checkbox = document.querySelectorAll('.filter-check_checkbox');

for (let i = 0; i < checkbox.length; i++) {
    checkbox[i].addEventListener('change', function(){
        if (this.checked){
           this.nextElementSibling.classList.add('checked');
        } else {
           this.nextElementSibling.classList.remove('checked');
        }
       });     
}


//_________Корзина

const btnCart = document.getElementById('cart');
const modalCart = document.querySelector('.cart');
const btnClose = document.querySelector('.cart-close');

btnCart.addEventListener('click', () => {
    modalCart.style.display = 'flex';
  //  modalCart.style.backgroundColor = 'red';
  document.body.style.overflow = 'hidden';
});

btnClose.addEventListener('click', () => {
    modalCart.style.display = '';
    document.body.style.overflow = '';
});


//_______Товары


const cards = document.querySelectorAll('.goods .card'),
cartWrapper = document.querySelector('.cart-wrapper'),
cartEmpty = document.getElementById('cart-empty'),
countGoods = document.querySelector('.counter');

cards.forEach((card) => {
const btn = card.querySelector ('button');

btn.addEventListener('click', () => {
  const cardClone = card.cloneNode(true);
  cartWrapper.appendChild(cardClone);
  cartEmpty.remove();
  showData();  
});
});


function showData() {
    const cardsCart = cartWrapper.querySelectorAll('.card');
    countGoods.textContent = cardsCart.length;
    console.log(cardsCart.length);
}

/*

единичный
const checkbox = document.getElementById('discount-checkbox');

checkbox.addEventListener('change', function(){
 if (this.checked){
    this.nextElementSibling.classList.add('checked');
 } else {
    this.nextElementSibling.classList.remove('checked');
 }
});

*/

//Убрать чекбокс